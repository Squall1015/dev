alert(user); // no such variable (each module has independent variables)
