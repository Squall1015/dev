const DEFAULT_ROLE = 'user'

export {DEFAULT_ROLE}