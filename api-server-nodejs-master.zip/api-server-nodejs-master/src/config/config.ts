/*

Copyright (c) 2019 - present AppSeed.us

*/
export default {
  webURL: 'https://localhost:5000/',
};
