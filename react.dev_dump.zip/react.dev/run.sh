curl https://react.dev/_next/static/chunks/61.58bf4d14910b9509.js --output _next/static/chunks/61.58bf4d14910b9509.js



curl https://react.dev/_next/static/chunks/641.3fe95b0e522a7937.js --output _next/static/chunks/641.3fe95b0e522a7937.js