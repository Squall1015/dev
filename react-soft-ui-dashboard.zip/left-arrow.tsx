function LeftArrow() {
  return (
    <>
      <h1>LeftArrow</h1>
    </>
  );
}

export default LeftArrow;
